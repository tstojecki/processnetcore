﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iCal
{
    public interface ICalendarParameterListContainer        
    {
        ICalendarParameterList Parameters { get; }
    }
}
