﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iCal
{
    public interface ICalendarPropertyCompositeList<T> :
        IList<T>
    {        
    }
}
