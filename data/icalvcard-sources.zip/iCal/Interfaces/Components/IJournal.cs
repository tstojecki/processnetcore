﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iCal
{
    public interface IJournal :
        IRecurringComponent
    {
        JournalStatus Status { get; set; }
    }
}
