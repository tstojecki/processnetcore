namespace antlr.debug
{
	using System;

	internal interface NewLineListener : Listener
	{
		void hitNewLine(object source, NewLineEventArgs e);
	}
}