namespace antlr.debug
{
	using System;


	internal interface Listener
	{
		void  doneParsing	(object source, TraceEventArgs e);
		void  refresh		();
	}
}