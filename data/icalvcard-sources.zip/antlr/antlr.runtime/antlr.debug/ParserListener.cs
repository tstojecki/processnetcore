namespace antlr.debug
{
	using System;

	internal interface ParserListener : SemanticPredicateListener, ParserMatchListener, MessageListener, ParserTokenListener, TraceListener, SyntacticPredicateListener
	{
	}
}