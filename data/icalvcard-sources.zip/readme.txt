iCalvCard.sln - .NET 2.0/3.5 (Visual Studio 2008)
iCalvCard.4.sln - .NET 4.0/4.5 Client Profile (Visual Studio 2010+)